INSERT INTO `{wp_prefix}wpda_media` (`media_table_name`, `media_column_name`, `media_type`, `media_activated`) VALUES ('wpda_bas_bike','bike_attachments','Attachment','Yes');
INSERT INTO `{wp_prefix}wpda_media` (`media_table_name`, `media_column_name`, `media_type`, `media_activated`) VALUES ('wpda_bas_bike','bike_photo','Image','Yes');
