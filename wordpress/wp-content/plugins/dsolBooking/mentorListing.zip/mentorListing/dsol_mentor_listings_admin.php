<?php
class DsolMentorListingsAdmin{
    public static function adminPage(){
        require_once(DSOL_LISTING_PATH . '/admin/mainPage.html');
    }
}
?>