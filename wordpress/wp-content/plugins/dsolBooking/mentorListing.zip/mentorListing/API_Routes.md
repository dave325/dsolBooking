# RESTFUL API Routes 

#### Note: All the requests below must be called with method of `POST`

#### All URL Endpoints will start with:
`http://localhost:[port number]/wordpress/wp-json/mentor-listing/v1/...`

---

### Mentors (Profiles)
1. Get all mentors 
	
   Make request to `"/profiles"`
   
   Will return a JSON object containing a list of all mentors (with mentor information, skills, certifications, and available times)
    
2. Get mentors (with limiter)

	Make request to `"/profiles/limit/[$page_number]"`
    
    Will return a JSON object containing a list of 25 mentors (with mentor information, skills, certifications, and available times) based on the $page_number passed in.

3. Get a mentor (one profile)
	
    Make request to `"/profile/[$mentor_id]"`
    
    Will return a JSON object containing mentor information, skills, certifications, and available times of the $mentor_id passed in.
	
4. Create a mentor

	Make request to `"/profile/create"`
    
    **Requires JSON body of the following format:** 
    ```json
    	{
          "availableTimes": {
						"startDate": "2019-01-01",
						"endDate": "2019-01-25",
						"openTime": "09:00:00",
						"closeTime": "17:00:00",
            "recurring": 1
          },
          "skills": [
						"Freezing",
						"Eating",
						"Sleeping"
          ],
          "certifications": [
						"OPE Academy",
						"ZBF Academy",
						"EAK Academy"
          ]
		}
	```
  	Will return a `Success` message upon a successful creation of mentor.
	
5. Update a mentor
	
    Make request to `"/profile/edit"`
    
    **Requires JSON body of the following format:** 
    
    User **must** be logged in as the current mentor
    
    Can pass in `name` and/or `email`
    
   ```json
    	{
				"name": "John Legend",
				"email": "Legend@gmail.com"
			}
   ```
   
   Will return a `Success` message upon a successful update of mentor.

6. Delete a mentor
	
    Make request to `"/profile/delete"`
     
    User **must** be logged in as the current mentor
    
    Will return a `Success` message upon a successful deletion of mentor. Calling this route will only delete all the mentor's information that are relevant to mentorListing and NOT the actual user!

7. Update skills

	Make request to `"/profile/skills/update
	
	User **must** be logged in as the current mentor
	
	**Requires JSON body of the following format:** 
	
	```json
		{
			"skills": [
				"fishing",
				"woodcutting"
			]
		}
	```
	
	Will return a `Success` message upon a successful update of skills for mentor.
	

8. Update certifications

	Make request to `"/profile/certs/update"`
	
	User **must** be logged in as the current mentor
	
	**Requires JSON body of the following format:** 
	
	```json
		{
			"certifications": [
				"ABC Academy",
				"DEF Academy"
			]
		}
	```
	
	Will return a `Success` message upon a successful update of certifications for mentor.
	

8. Delete a skill and/or certification

	Make request to `"/profile/qualifications/delete"`
    
    User **must** be logged in as the current mentor
    
    **Requires JSON body of the following format:** 
    
    Can pass in skills and/or certifications object with the skill/qualification ID(s).
    
    ```json
    	{
        	"skills": [ 1,2],
          "certifications": [1]
        }
    ```

	Will return a `Success` message upon a successful deletion of a qualification.

9. Get pagination number
	
	Make request to `/profiles/count`
	
	Returns the total page numbers, assuming each page can have 25 mentors.
	
10. Create an Available Time for a mentor

	Make request to `/profile/availableTimes/create`
	
	 User **must** be logged in as the current mentor
    
    **Requires JSON body of the following format:** 
		
		```json
			{
				"availableTimes": [
					{
						"startDate": "2019-01-01",
						"endDate": "2019-01-25",
						"openTime": "09:00:00",
						"closeTime": "17:00:00",
            "recurring": 1					
					},
					{
						...
					}
				]
			}
		```

11. Edit Available Times for a mentor

	Make request to `/profile/availableTimes/edit`
	
	 User **must** be logged in as the current mentor
    
    **Requires JSON body of the following format:** 
		
		```json
			{
				"availableTimes": [
					{
						"startDate": "2019-01-01",
						"endDate": "2019-01-25",
						"openTime": "09:00:00",
						"closeTime": "17:00:00",
            "recurring": 1					
					},
					{
						...
					}
				]
			}
		```

12. Delete Available Times for a mentor

	Make request to `/profile/availableTimes/delete`
	
	 User **must** be logged in as the current mentor
	 
	 Each element in availableTimes represents a timeId that the current mentor would like to be deleted.
    
    **Requires JSON body of the following format:** 
		
		```json
			{
				"availableTimes": [
					1, 2, 3
				]
			}
		```

13. Get Profile for currently-logged in mentor

	Make request to `/profile/current`

	User **must** be logged in as the current mentor

	Returns the profile information for the currently-logged in mentor.



---

### Listings
1. Get all listings

  	Make request to `"/listings"`
   
   Will return a JSON object containing a list of all listings (with mentor information and all the reservations for each mentor)

2. Get listings (with limiter)

	Make request to `"/listings/limit/[$page_number]"`
    
    Will return a JSON object containing a list of 25 listings (with mentor information and all the reservations for each mentor based on the $page_number passed in.
    
3. Get a listing (one listing)

	Make request to `"/listings/[$listing_id]"`
    
    Will return a JSON object containing mentor information and all the reservations of the $listing_id passed in.
    
4. Create a listing
	
    Make request to `"/listing/create"`
    
    **Requires JSON body of the following format:** 
    
    ```json
    	{
				"mentorId": 7,
				"startTime": "2019-01-01 07:00:00",
				"endTime": "2019-01-01 12:00:00",
				"email": "stewart123@gmail.com",
				"name": "Jackie Stewart",
				"phone": "1-347-000-1111",
				"isApproved": 1
			}
    ```
    
     Will return a `Success` message upon a successful creation of a listing.

5. Edit a listing

 	Make request to `"/listing/edit"`
    
    User **must** be logged in as the current mentor
    
	Must pass in the corresponding fields of `timeId`, `startTime`, `endTime` for each time(s)
		
	**Requires JSON body of the following format:** 
    
    ```json
    {
  		"times": [
			{
				"timeId": 6,
				"startTime": "2019-01-01 07:30:00",
				"endTime": "2019-01-01 09:30:00",
				"reservationId": 1,
				"email": "check@gmail.com",
				"name":	"Check Man",
				"phone": "910-203-0213",
				"isApproved": 1
			},
			{
				...
			}
			]
		}
    ```
    
    Will return a `Success` message upon a successful update of a listing.
    
6. Delete a listing (only deletes a single listing per call)

	Make request to `"/listing/delete"`
     
    User **must** be logged in as the current mentor of the listing
    
    Will return a `Success` message upon a successful deletion of a listing.
		
	The number passed in represents the timeId of the listing that the mentor would like to delete.
		
	**Requires JSON body of the following format:** 
	
	```json
		{
			"time": 1
		}
	
	```

---

### Search (Filtering)
1. Get time intervals for mentor

	 Make request to `"/search/findIntervalMentor"`
     
     **Requires JSON body of the following format:** 
     
     ```json
     	{
				"startDate": "2019-01-01",
				"endDate": "2019-02-01"
      }
     ```
     Will return a JSON object containing a list of all mentors (with mentor information, skills, certifications, and available times) that fit the interval of the passed-in startTime and endTime.
    
2. Get time intervals for listing

	Make request to `"/search/findIntervalListing"`
    
    **Requires JSON body of the following format:** 
    
    ```json
     	{
				"startDate": "2019-01-01",
				"endDate": "2019-02-01"
      }
     ```
     
     Will return a JSON object containing a list of all listings (with mentor information and all the reservations for each mentor) that fit the interval of the passed-in startTime and endTime.
    
    
3. Get search results by name

	Make request to `"/search/filter-name"`
    
    **Requires JSON body of the following format:** 
    
    Can pass in surname and/or forename (ie. "jackie", "stewart", or "jackie stewart".
    
    All these fields are case-insensitive.
    
    ```json
    	{
       	"name": "Jackie Stewart"
      }
    ```
    
    Will return a JSON object containing a list of all mentors (with mentor information, skills, certifications, and available times) that contain the passed-in name.
    
	
4. Get search results by skills

	Make request to `"/search/filter-skills"`
    
    **Requires JSON body of the following format:** 
    
    All these fields are case-insensitive.
    
    ```json
    	{
       	"skills": [
          "woodcutting",
          "fishing"
        ]
      }
    ```
    
    Will return a JSON object containing a list of all mentors (with mentor information, skills, certifications, and available times) that have the following skills.


5. Get search results by certifications

	Make request to `"/search/filter-certs"`
    
    **Requires JSON body of the following format:** 
    
    All these fields are case-insensitive.
    
    ```json
    	{
       	"certifications": [
          "aws academy",
	        "mna academy"
        ]
      }
    ```
    
    Will return a JSON object containing a list of all mentors (with mentor information, skills, certifications, and available times) that have the following certifications.
		
6. Get the availableTimes and listings for a mentor

	Make request to `"/search/filter-times/:id"` where the id corresponds to the mentorId for that particular mentor.
	
	Will return a JSON object containing a list of all the availableTimes and listings for that particular mentor.
	

---

### FORMATS (String concatentation formats)

Note: Each of the following categories will be returned as one entire string per `mentor` in the following order. Each individual element of the following types: available times, skills, certifications, or reservations are separated by a semicolon `;`, with each field of that element separated by either a comma `,` or colon `:`.

1. AvailableTimes
	`"timeId, startDate, endDate, openTime, closeTime, recurring ; ..."`
2. Skills
	`"skillId: skillName ; ..."`
3. Certifications
	`"certificationId: certificationName ; ..."`
4. Reservations
	`"reservationId, email, name, phone, timeId, startTime, endTime ; ..."`


---
