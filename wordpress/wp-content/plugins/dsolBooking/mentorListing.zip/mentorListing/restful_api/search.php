<?php 
require_once('Authentication.php');

class Search_Posts_Controller 
{

  public function __construct()
  {
    $this->namespace = 'mentor-listing/v1';
    $this->resource_name = 'search';
  }

  public function register_routes()
  {
    register_rest_route($this->namespace, '/testsearch', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'test')
      )
    ));

    register_rest_route($this->namespace, '/search/findIntervalMentor', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'findIntervalMentor')
      )
    ));

    register_rest_route($this->namespace, '/search/findIntervalListing', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'findIntervalListing')
      )
    ));

    register_rest_route($this->namespace, '/search/filter-name', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'filter_name')
      )
    ));

    register_rest_route($this->namespace, '/search/filter-skills', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'filter_skills')
      )
    ));

    register_rest_route($this->namespace, '/search/filter-certs', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'filter_certs')
      )
    ));

    register_rest_route($this->namespace, '/search/filter-times/(?P<id>\d+)', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'filter_times')
      )
    ));
  }

  public function test(WP_REST_Request $request){
    $success = 'You have successfully connected to the search TEST route';
    return rest_ensure_response($success);
  } 

  public function findIntervalMentor(WP_REST_Request $request){
    
    global $wpdb;
    
    /**
     *  Required Info:
     * 
     *  - startDate
     *  - endDate
     * 
     * 
     */

    $post_array = $request->get_json_params();
    $startDate = $post_array['startDate'];
    $endDate = $post_array['endDate'];

    $sql = "SELECT 
              m.user_id AS mentorId,
              u.user_email AS mentorEmail,
              u.user_nicename AS mentorName,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(', ', awt.timeId, awt.startDate, awt.endDate, awt.openTime, awt.closeTime, awt.recurring)
                SEPARATOR ' ; ' 
              ) AS availableTimes
            FROM wp_usermeta m
            INNER JOIN wp_users u 
              on m.user_id = u.ID
            LEFT JOIN wp_AvailableTime awt 
              ON m.user_id = awt.mentorId
            WHERE awt.startDate <= \"$endDate\" AND awt.endDate >= \"$startDate\"
              AND m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
            GROUP BY m.user_id, u.user_email, u.user_nicename";

    $interval_result = $wpdb->get_results($sql, ARRAY_A);

    if(!empty($wpdb->last_error)){
      return new WP_Error(400, $wpdb->last_error);
    } 

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($interval_result);
    } else {
      return rest_ensure_response([]);
    }

  }


  public function findIntervalListing(WP_REST_Request $request){
    
    global $wpdb;
    
    /**
     *  Required Info:
     * 
     *  - startTime
     *  - endTime
     * 
     * 
     */

    $post_array = $request->get_json_params();
    $startDate = $post_array['startDate'];
    $endDate = $post_array['endDate'];

    $sql = "SELECT 
              m.user_id AS mentorId,
              u.user_email AS mentorEmail,
              u.user_nicename AS mentorName,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(', ', r.reservationId, r.email, r.name, r.phone, rt.timeId, rt.startTime, rt.endTime)
                SEPARATOR '; '
              ) AS reservations
            FROM wp_usermeta m
            INNER JOIN wp_users u 
              ON m.user_id = u.ID
            LEFT JOIN wp_AvailableTime awt
              ON m.user_id = awt.mentorId
            LEFT JOIN wp_ReservationMentorMap c
              ON m.user_id = c.mentorId
            LEFT JOIN wp_reservation r
              ON c.reservationId = r.reservationId
            LEFT JOIN wp_reservationTime rt
              ON r.timeId = rt.timeId
            WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}' 
              AND rt.startTime <= \"$endDate\"
              AND rt.endTime >= \"$startDate\"
            GROUP BY m.user_id, u.user_email, u.user_nicename";

    $interval_result = $wpdb->get_results($sql, ARRAY_A);

    if(!empty($wpdb->last_error)){
      return new WP_Error(400, $wpdb->last_error);
    } 

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($interval_result);
    } else {
      return rest_ensure_response([]);
    }

  }

  public function filter_name(WP_REST_Request $request) {

    global $wpdb;

    $post_array = $request->get_json_params();

    $possible_name = trim(strtolower($post_array['name']));
    $q = new WP_Query( array(
      'meta_query' => array(
          'relation' => 'OR',
          array(
              'key' => 'first_name',
              'value' => $possible_name,
          ),
          array(
              'key' => 'last_name',
              'compare' => $possible_name,
          ), 
      ),
  ) );
  $res = $q->get_queried_object();
  return rest_ensure_response($res);
    $sql = "SELECT
                m.user_id AS mentorId
              FROM wp_usermeta m
              WHERE m.meta_key = 'first_name'
                AND m.meta_value LIKE \"%$possible_name%\"
                AND u.user_nicename LIKE \"%$possible_name%\"
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename";
                        // TODO - use first name and last name

      $results = $wpdb->get_results($sql, ARRAY_A);

      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } 
  
      if ($wpdb->num_rows > 0) {
        return rest_ensure_response($results);
      } else {
        return rest_ensure_response([]);
      }
  }

  public function filter_skills (WP_REST_Request $request){

    global $wpdb;
    $post_array = $request->get_json_params();


    $skills = array_map(function($skill)
      {
        return trim(strtolower($skill));
      }, 
      $post_array['skills']);

    $skills_length = count($skills);

    $str = "'" . implode("','", $skills) . "'";
    $users = get_users(array(
      'role' => 'mentor',
      'meta_key' => 'skills',
      'meta_value' => $str,
      'meta_compare' => 'IN',
      
    ));
    $info = array();
    foreach($users as $id){
      $id->data->skills = explode(",",get_user_meta($id->ID, 'skills', true));
      $id->data->certifications = explode(",",get_user_meta($id->ID, 'certifications', true));
    }
    return rest_ensure_response($users);
    $sql = "SELECT s.skillId, s.skillName, s.mentorId FROM wp_skill s WHERE s.skillName IN ($str)";
    $result = $wpdb->get_results($sql, ARRAY_A);

    $dupl = [];
    $mentors = [];

    foreach($result as $value){
      $mentorId = $value['mentorId'];
      
      if ($dupl[$mentorId]){
        ++$dupl[$value['mentorId']];
      } else {
        $dupl[$mentorId] = 1;
      }

      if ($dupl[$mentorId] == $skills_length){
        $mentors[] = intval($mentorId,10);
      }
    }


    $mentor_results = [];
    
    foreach($mentors as $mentor){
      
      $sql = "SELECT
                m.user_id AS mentorId,
                u.user_email AS mentorEmail,
                u.user_nicename AS mentorName,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(': ', s.skillId, s.skillName)
                  SEPARATOR ' ; ' 
                ) AS skills,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(': ',  c.certificationId, c.certificationName)
                  SEPARATOR ' ; ' 
                ) AS certs,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(', ', awt.timeId, awt.startDate, awt.endDate, awt.openTime, awt.closeTime, awt.recurring)
                  SEPARATOR ' ; ' 
                ) AS availableTimes
              FROM wp_usermeta m
              INNER JOIN wp_users u 
                ON m.user_id = u.ID
              LEFT JOIN wp_skill s 
                on m.user_id = s.mentorId
              LEFT JOIN wp_certification c 
                on m.user_id = c.mentorId
              LEFT JOIN wp_AvailableTime awt 
                on m.user_id = awt.mentorId
              WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}' 
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename";

      $results = $wpdb->get_results($sql, ARRAY_A);

      $mentor_results[$mentor] = $results;
    }

    if(!empty($wpdb->last_error)){
      return new WP_Error(400, $wpdb->last_error);
    } 

    if (count($mentor_results) > 0){
      return rest_ensure_response($mentor_results);
    } else {
      return rest_ensure_response([]);
    }
    

  }

  public function filter_certs (WP_REST_Request $request){

    global $wpdb;
    $post_array = $request->get_json_params();

    $certifications = array_map(function($cert){
      return trim(strtolower($cert));
    }, $post_array['certifications']);
    
    $certifications_length = count($certifications);

    $str = "'" . implode("','", $certifications) . "'";
/*
    $sql = "SELECT c.certificationId, c.certificationName, c.mentorId FROM wp_certification c WHERE c.certificationName IN ($str)";
    $result = $wpdb->get_results($sql, ARRAY_A);


    $dupl = [];
    $mentors = [];

    foreach($result as $value){
      $mentorId = $value['mentorId'];
      
      if ($dupl[$mentorId]){
        ++$dupl[$value['mentorId']];
      } else {
        $dupl[$mentorId] = 1;
      }

      if ($dupl[$mentorId] == $certifications_length){
        $mentors[] = intval($mentorId,10);
      }
    }
*/

    $users = get_users(array(
      'role' => 'mentor',
      'meta_key' => 'certifications',
      'meta_value' => $str,
      'meta_compare' => 'IN',
      
    ));
    $info = array();
    foreach($users as $id){
      $id->data->skills = explode(",",get_user_meta($id->ID, 'skills', true));
      $id->data->certifications = explode(",",get_user_meta($id->ID, 'certifications', true));
    }
    return rest_ensure_response($users);
    $mentor_results = [];

      
      $sql = "SELECT
                m.user_id
                m.user_id AS mentorId,S
              FROM wp_usermeta m
              INNER JOIN wp_users u 
                ON m.user_id = u.ID
              WHERE m.meta_key = 'certifications'
              AND m.meta_value IN {$str}
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename";

      $results = $wpdb->get_results($sql, ARRAY_A);



    if(!empty($wpdb->last_error)){
      return new WP_Error(400, $wpdb->last_error);
    } 

    if (count($mentor_results) > 0){
      return rest_ensure_response($mentor_results);
    } else {
      return rest_ensure_response([]);
    }
    
  }


  public function filter_times(WP_REST_Request $request){

    global $wpdb;

    $mentorId = is_numeric($request['id']) ? intval($request['id']) : null;

    if ($mentorId){
      
      $sql = "SELECT
              m.user_id AS mentorId,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(', ', awt.timeId, awt.startDate, awt.endDate, awt.openTime, awt.closeTime, awt.recurring)
                SEPARATOR ' ; ' 
              ) AS availableTimes,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(', ', r.reservationId, r.email, r.name, r.phone, rt.timeId, rt.startTime, rt.endTime )
                SEPARATOR ' ; ' 
              ) AS reservations
              FROM wp_usermeta m
              INNER JOIN wp_users u 
                ON m.user_id = u.ID
              LEFT JOIN wp_AvailableTime awt 
                on m.user_id = awt.mentorId
              LEFT JOIN wp_ReservationMentorMap c
                ON m.user_id = c.mentorId
              LEFT JOIN wp_reservation r
                ON c.reservationId = r.reservationId
              LEFT JOIN wp_reservationTime rt
                ON r.timeId = rt.timeId
              WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}' 
                AND m.user_id = $mentorId
              GROUP BY m.user_id";
      
      $results = $wpdb->get_results($sql, ARRAY_A);
      $availableTimes = explode(";", $results[0]['availableTimes']);
      $reservations = explode (";", $results[0]['reservations']);

      $times = [];

      foreach($availableTimes as $timeInfo){
        $details = explode(",", $timeInfo);
        $times[] = array (
          "timeId" => trim($details[0]),
          "startDate" => trim($details[1]),
          "endDate" => trim($details[2]),
          "openTime" => trim($details[3]),
          "closeTime" => trim($details[4]),
          "recurring" => trim($details[5])
        );
      }

      $listings = [];

      foreach($reservations as $res){
        $details = explode(",", $res);
        $listings[] = array (
          "resId" => trim($details[0]),
          "email" => trim($details[1]),
          "name" => trim($details[2]),
          "phone" => trim($details[3]),
          "startTime" => trim($details[5]),
          "endTime" => trim($details[6])
        );
      }

      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } 

      if (count($times) > 0 && count($listings) > 0){
        return rest_ensure_response(array(
          "availableTimes" => $times,
          "listings" => $listings
        ));
      } else {
        return rest_ensure_response([]);
      }
    }
    
  }


}






?>
