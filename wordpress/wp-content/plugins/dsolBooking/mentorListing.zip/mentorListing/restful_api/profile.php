<?php
require_once('Authentication.php');

class Profile_Posts_Controller
{

  public function __construct()
  {
    $this->namespace = 'mentor-listing/v1';
    $this->resource_name = 'profiles';
  }

  public function register_routes()
  {
    register_rest_route($this->namespace, '/testprofile', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'test')
      )
    ));

    register_rest_route($this->namespace, '/profiles', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_profiles_all')
      )
    ));

    register_rest_route($this->namespace, '/profiles/count', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'count_profiles')
      )
    ));

    register_rest_route($this->namespace, '/profile/create', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'create_profile')
      )
    ));

    register_rest_route($this->namespace, '/profile/(?P<id>\d+)', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_profile')
      )
    ));

    register_rest_route($this->namespace, '/profiles/limit/(?P<limit>\d+)', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_profiles_limit')
      )
    ));


    register_rest_route($this->namespace, '/profile/current', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_current_profile')
      )
    ));

    register_rest_route($this->namespace, '/profile/edit', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'edit_profile')
      )
    ));

    register_rest_route($this->namespace, '/profile/availableTimes/create', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'create_availableTimes')
      )
    ));

    register_rest_route($this->namespace, '/profile/availableTimes/', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_availableTimes')
      )
    ));

    register_rest_route($this->namespace, '/profile/availableTimes/edit', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'edit_availableTimes')
      )
    ));

    register_rest_route($this->namespace, '/profile/availableTimes/delete', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'delete_availableTimes')
      )
    ));

    // *** DO NOT USE THIS ROUTE ***
    // register_rest_route($this->namespace, '/profile/qualifications/edit', array(
    //   // Here we register the readable endpoint for collections.
    //   array(
    //       'methods'   => 'POST',
    //       'callback'  => array($this, 'edit_qualifications')
    //   )
    // ));

    register_rest_route($this->namespace, '/profile/skills/update', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'update_skills')
      )
    ));

    register_rest_route($this->namespace, '/profile/certs/update', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'update_certs')
      )
    ));

    register_rest_route($this->namespace, '/profile/qualifications/delete', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'delete_qualifications')
      )
    ));

    register_rest_route($this->namespace, '/profile/delete', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'delete_profile')
      )
    ));
  }

  public function test(WP_REST_Request $request)
  {
    $success = 'You have successfully connected to the profile TEST route';
    return rest_ensure_response($success);
  }

  public function count_profiles(WP_REST_Request $request)
  {
    global $wpdb;

    $sql = "SELECT count(mentorId) AS mentorCount FROM wp_Mentor";
    $result = $wpdb->get_results($sql, ARRAY_A);
    $pageCount = ceil(intval($result[0]['mentorCount'], 10) / 25);
    return $pageCount;
  }

  public function get_profiles_all(WP_REST_Request $request)
  {
    global $wpdb;
    $all_skills = array();
    // if (Authentication::authorization_status_code() == 200) {
    $users = get_users(array(
      'role' => 'mentor'
    ));
    $info = array();
    foreach ($users as $id) {
      $id->data->skills = explode(",", get_user_meta($id->ID, 'skills', true));
      $id->data->certifications = explode(",", get_user_meta($id->ID, 'certifications', true));
    }
    return rest_ensure_response($all_skills);
    $sql = "SELECT
              m.user_id AS mentorId,
              u.user_email AS mentorEmail,
              u.user_nicename AS mentorName,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(', ', awt.timeId, awt.date, awt.time)
                SEPARATOR ' ; ' 
              ) AS availableTimes,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(': ', s.skillId, s.skillName)
                SEPARATOR ' ; ' 
              ) AS skills,
              GROUP_CONCAT(
                DISTINCT CONCAT_WS(': ',  c.certificationId, c.certificationName)
                SEPARATOR ' ; ' 
              ) AS certs 
            FROM wp_usermeta m
            INNER JOIN wp_users u 
              on m.user_id = u.ID
            LEFT JOIN wp_skill s 
              on m.user_id = s.mentorId
            LEFT JOIN wp_certification c 
              on m.user_id = c.mentorId
            LEFT JOIN wp_AvailableTime awt 
              on m.user_id = awt.mentorId
            WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
            GROUP BY  m.user_id,
                      u.user_email,
                      u.user_nicename";

    $results = $wpdb->get_results($sql, ARRAY_A);

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    }

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($results);
    } else {
      return rest_ensure_response([]);
    }
    // }
  }

  public function get_availableTimes(WP_REST_Request $request)
  {
    global $wpdb;

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $sql = "SELECT
                m.user_id AS mentorId,
                u.user_email AS mentorEmail,
                u.user_nicename AS mentorName,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(', ', awt.timeId, awt.startDate, awt.endDate, awt.openTime, awt.closeTime, awt.recurring)
                  SEPARATOR ' ; ' 
                ) AS availableTimes,
              FROM wp_usermeta m
              INNER JOIN wp_users u 
                on m.user_id = u.ID
              LEFT JOIN wp_skill s 
                on m.user_id = s.mentorId
              LEFT JOIN wp_certification c 
                on m.user_id = c.mentorId
              LEFT JOIN wp_AvailableTime awt 
                on m.user_id = awt.mentorId
              WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                AND m.user_id = $mentorId
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename";

    $results = $wpdb->get_results($sql, ARRAY_A);

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    }

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($results);
    } else {
      return rest_ensure_response([]);
    }
  }

  public function create_profile(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     * 
     *    - startDate
     *    - endDate
     *    - openTime
     *    - closeTime
     *    - recurring
     * 
     *    - skillName
     * 
     *    - certificationName
     * 
     */

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $post_array = $request->get_json_params();


    // # Add into mentor
    // $wpdb->insert(
    //   'wp_Mentor', 
    //   array(
    //     "mentor_name" => $post_array['mentor']['mentorName'],
    //     "email" => $post_array['mentor']['email']
    //   )
    // );

    // if (!$wpdb->insert_id){
    //   return rest_ensure_response($error_message);
    // }

    // $mentorId = $wpdb->insert_id;

    # Add into skills
    $skills = $post_array['skills'];
    foreach ($skills as $skill) {
      $wpdb->insert(
        'wp_skill',
        array(
          "skillName" => strtolower($skill),
          "mentorId" => $mentorId
        )
      );
    }

    # Add into certifications
    $certs = $post_array['certifications'];
    foreach ($certs as $cert) {
      $wpdb->insert(
        'wp_certification',
        array(
          "certificationName" => strtolower($cert),
          "mentorId" => $mentorId
        )
      );
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor profile has been successfully created."
      ));
    }

    // }
  }

  public function get_profile(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     * 
     *    - mentorId
     * 
     */

    $mentorId = is_numeric($request['id']) ? intval($request['id']) : null;
    $users = get_users(array(
      'role' => 'mentor'
    ));
    $info = array();
    foreach ($users as $id) {
      $id->data->skills = explode(",", get_user_meta($id->ID, 'skills', true));
      $id->data->certifications = explode(",", get_user_meta($id->ID, 'certifications', true));
    }
    return rest_ensure_response($users);

    $sql = "SELECT
                m.user_id AS mentorId,
                u.user_email AS mentorEmail,
                u.user_nicename AS mentorName,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(', ', awt.timeId, awt.date, awt.time)
                  SEPARATOR ' ; ' 
                ) AS availableTimes,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(': ', s.skillId, s.skillName)
                  SEPARATOR ' ; ' 
                ) AS skills,
                GROUP_CONCAT(
                  DISTINCT CONCAT_WS(': ',  c.certificationId, c.certificationName)
                  SEPARATOR ' ; ' 
                ) AS certs 
              FROM wp_usermeta m
              INNER JOIN wp_users u 
                on m.user_id = u.ID
              LEFT JOIN wp_skill s 
                on m.user_id = s.mentorId
              LEFT JOIN wp_certification c 
                on m.user_id = c.mentorId
              LEFT JOIN wp_AvailableTime awt 
                on m.user_id = awt.mentorId
              WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                AND m.user_id = $mentorId
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename";

    $results = $wpdb->get_results($sql, ARRAY_A);

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    }

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($results);
    } else {
      return rest_ensure_response([]);
    }

    // }
  }

  public function get_profiles_limit(WP_REST_Request $request)
  {

    global $wpdb;

    $pageIndex = is_numeric($request['limit']) ? intval($request['limit']) : null;

    /**
     *  startIndex = (25 * ($pageIndex-1)) + 1
     *  endIndex = 25 * $pageIndex
     * 
     */

    $startIndex = (25 * ($pageIndex - 1));
    $endIndex = 25 * $pageIndex;
    $id = null;
    $users = get_users(array(
      'role' => 'mentor',
      'offset' => $startIndex,
      'number' => $endIndex,
    ));
    $info = array();
    $all_skills = array();
    $all_certifications = array();
    foreach ($users as $id) {
      $tempSkill = str_replace(' ', '', get_user_meta($id->ID, 'skills', true));
      $id->data->skills = explode(",", $tempSkill);

      if (strlen($tempSkill) > 0) {
        $all_skills = array_unique(array_merge($all_skills, $id->data->skills));
      }
      $tempCert = str_replace(' ', '', get_user_meta($id->ID, 'certifications', true));
      $id->data->certifications = explode(",", $tempCert);
      if (strlen($tempCert) > 0) {

        $all_certifications = array_unique(array_merge($all_certifications, $id->data->certifications));
      }
    }
    return rest_ensure_response(array($users, $all_skills, $all_certifications));
    // Removed where claused that looked for indexes 
    // Should not look for that specifically, always use limit
    $sql = "SELECT
              case 
                when m.meta_key = 'skills' THEN m.meta_value 
              END as skills
              FROM wp_usermeta m
              WHERE m.user_id IN (" . implode(",", $users) . ")
              GROUP BY  m.user_id
              LIMIT $startIndex, $endIndex";

    $results = $wpdb->get_results($sql, OBJECT_K);

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    }
    return rest_ensure_response($results);
    /**
     * Parse times from db and return as object
     */
    $mentors = array();
    foreach ($results as $mentor) {

      /*
        $mentor->selectedTime = explode(";", $mentor->selectedTime);
        $mentor->availableTimes = explode(';', $mentor->availableTimes);
        if(strlen($mentor->skills) > 0){
          $mentor->skills = explode(',', $mentor->skills);
        }else{
          $mentor->skills = array();
        }
        if(strlen($mentor->certifications) > 0){
          $mentor->certifications = explode(',',$mentor->certifications);
        }else{
          $mentor->certifications = array();
        }
        
        for($i = 0; $i < count($mentor->selectedTime); $i++){
          $mentor->availableTimes[$i] = json_decode($mentor->availableTimes[$i]);
          $mentor->availableTimes[$i]->time = json_decode($mentor->selectedTime[$i]);
        }
        unset($mentor->selectedTime);
        */
      array_push($mentors, $mentor);
    }

    if ($wpdb->num_rows > 0) {
      return rest_ensure_response($mentors);
    } else {
      // Will return an empty object if num_rows == 0
      return rest_ensure_response([]);
    }
  }

  public function get_current_profile(WP_REST_Request $request)
  {
    global $wpdb;

    $current_user = wp_get_current_user();
    $current_user->data->skills = get_usermeta($current_user->ID, 'year_of_birth');
    return rest_ensure_response($current_user);
    $mentorId = $current_user->ID;
    $sql = "SELECT 
                s.skillName AS skills,
                 c.certificationName AS certifications  
              FROM wp_usermeta m
              LEFT JOIN wp_skill s 
                on m.user_id = s.mentorId
              LEFT JOIN wp_certification c 
                on m.user_id = c.mentorId
              LEFT JOIN wp_AvailableTime awt 
                on m.user_id = awt.mentorId,
              LEFT JOIN wp_dsol_altered_dates ad
                on m.user_id = ad.mentor_id 
              WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                AND m.user_id = $mentorId
              GROUP BY  m.user_id,
                        u.user_email,
                        u.user_nicename
              LIMIT 1";

    $mentor = $wpdb->get_row($sql);

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    }
    /**
     * Parse times from db and return as object
     */
    if (strlen($mentor->skills) > 0) {
      $mentor->skills = explode(',', str_replace(' ', '', $mentor->skills));
    } else {
      $mentor->skills = array();
    }
    if (strlen($mentor->certifications) > 0) {
      $mentor->certifications = explode(',', str_replace(' ', '', $mentor->certifications));
    } else {
      $mentor->certifications = array();
    }

    return rest_ensure_response($mentor);
  }

  public function edit_profile(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     *   - name
     *   - email
     * 
     */

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    // if ($mentorId){
    // user is logged in as the current user
    $post_array = $request->get_json_params();
    /*
        $update_result = $wpdb->update(
          'wp_Mentor',
          array(
            'mentor_name' => strtolower($post_array['name']),
            'email' => strtolower($post_array['email'])
          ),
          array('mentorId'=> $mentorId)
        );
        */
    wp_update_user(array(
      'ID' => $mentorId,
      'user_nicename' => strtolower($post_array['name']),
      'user_email' => strtolower($post_array['email'])
    ));

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor has been updated."
      ));
    }

    // } else {
    // user is not logged in as the current user
    // }

  }

  public function create_availableTimes(WP_REST_Request $request)
  {
    global $wpdb;
    /**
     *  startDate
     *  endDate
     *  openTime
     *  closeTime
     *  recurring
     *  mentorId
     *  
     * 
     */

    $post_array = $request->get_json_params();

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $availableTimes = $post_array['availableTimes'];

    # Add into availableTime
    foreach ($availableTimes as $time) {
      $wpdb->insert(
        'wp_AvailableTime',
        array(
          "startDate" => $time['startDate'],
          "endDate" => $time['endDate'],
          "openTime" => $time['openTime'],
          "closeTime" => $time['closeTime'],
          "recurring" => $time['recurring'],
          "mentorId" => $mentorId
        )
      );
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's availableTimes have been created."
      ));
    }
  }

  public function edit_availableTimes(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *  
     *  Required Info:
     *  - timeId
     *  - startDate
     *  - endDate
     *  - openTime
     *  - closeTime
     *  - recurring
     * 
     * 
     */

    $current_user = wp_get_current_user();

    $post_array = $request->get_json_params();

    $availableTimes = $post_array['selectedTimesIdx'];

    if (isset($post_array['add']) && $post_array['add']) {
      $wpdb->insert('wp_AvailableTime', array(
        'date' =>  date('Y-m-d H:i:s', strtotime($post_array['date'])),
        'time' => $availableTimes,
        'mentorId' => $current_user->ID,
        'isWeekly' => $post_array['isWeekly'],
        'dayOfWeek' => $post_array['dayOfWeek']
      ));
    } else {
      $wpdb->update('wp_AvailableTime', array(
        'date' =>  date('Y-m-d H:i:s', strtotime($post_array['date'])),
        'time' => $availableTimes,
        'mentorId' => $current_user->ID,
        'isWeekly' => $post_array['isWeekly'],
        'dayOfWeek' => $post_array['dayOfWeek']
      ), array(
        "id" => $post_array['timeId']
      ));
    }
    /*
      foreach ($availableTimes as $time){
        $temp_start = date('Y-m-d H:i:s', $time['startTime']);
        $temp_end = date('Y-m-d H:i:s', $time['endTime']);
        if($post_array['add']){
          $wpdb->insert('wp_AvailableTime',array(
            'openTime' => $temp_start,
            'closeTime' => $temp_end,
            'mentorId' => $current_user->ID
          ));
          
        }elseif(!$post_array['add']){
          $wpdb->update(
            'wp_AvailableTime',
            array(
              //'startDate' => $time['startDate'],
              //'endDate' => $time['endDate'],
              'openTime' => $temp_start,
              'closeTime' => $temp_end,
              //'recurring' => $time['recurring']
            ),
            array('timeId' => $time['timeId'])
          );
        }

      }
      */
    if ($wpdb->last_error != '') {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's availableTimes have been updated."
      ));
    }

    //}
  }

  public function delete_availableTimes(WP_REST_Request $request)
  {
    global $wpdb;

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $post_array = $request->get_json_params();
    $availableTimes = $post_array['availableTimes'];

    foreach ($availableTimes as $timeId) {

      $wpdb->query(
        $wpdb->prepare(
          "DELETE FROM wp_AvailableTime WHERE mentorId = %d AND timeId = %d",
          array(
            $mentorId,
            $timeId
          )
        )
      );
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's availableTimes have been deleted."
      ));
    }
  }

  public function update_skills(WP_REST_Request $request)
  {
    global $wpdb;

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $post_array = $request->get_json_params();
    $skills = $post_array['skills'];

    $delete_result = $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_skill WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );


    foreach ($skills as $skill) {
      $wpdb->insert(
        'wp_skill',
        array(
          "skillName" => strtolower($skill),
          "mentorId" => $mentorId
        )
      );
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's skills have been updated/created."
      ));
    }
  }

  public function update_certs(WP_REST_Request $request)
  {
    global $wpdb;

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $post_array = $request->get_json_params();
    $certifications = $post_array['certifications'];

    $delete_result = $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_certification WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );

    foreach ($certifications as $cert) {
      $wpdb->insert(
        'wp_certification',
        array(
          "certificationName" => strtolower($cert),
          "mentorId" => $mentorId
        )
      );
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's certifications have been updated/created."
      ));
    }
  }

  // *** DO NOT USE THIS ROUTE ***
  // public function edit_qualifications(WP_REST_Request $request)
  // {
  //   global $wpdb;
  //   // if (Authentication::authorization_status_code() == 200) {

  //   /**
  //    *   Required info: 
  //    *   - skills []
  //    *   - certifications []
  //    * 
  //    */

  //     $current_user = wp_get_current_user();
  //     $mentorId = $current_user->ID;

  //     // if ($mentorId){
  //       // user is logged in as the current user
  //       $post_array = $request->get_json_params();

  //       if ($post_array['skills']){
  //         $skills = $post_array['skills']; 
  //         $skills_length = count($skills);

  //         for ($i=0; $i<$skills_length; $i++){
  //           if ($skills[$i]['skillId']){
  //             // update skill
  //             $skill = strtolower($skills[$i]['skillName']);
  //             $update_result = $wpdb->update(
  //               'wp_skill',
  //               array(
  //                 'skillName' => $skill
  //               ),
  //               array(
  //                 'mentorId' => $mentorId
  //               )
  //             );

  //           } else {
  //             // create cert
  //             $wpdb->insert(
  //               'wp_skill', 
  //               array(
  //                 "skillName" => strtolower($skills[$i]['skillName']),
  //                 "mentorId" => $mentorId
  //               )
  //             );

  //           }
  //         }

  //       }

  //       if ($post_array['certifications']){
  //         $certifications = $post_array['certifications']; 
  //         $certs_length = count($certifications);

  //         for ($i=0; $i<$certs_length; $i++){
  //           if ($certifications[$i]['certificationId']){
  //             // update cert
  //             $cert = strtolower($certifications[$i]['certificationName']);
  //             $update_result = $wpdb->update(
  //               'wp_certification',
  //               array(
  //                 'certificationName' => $cert
  //               ),
  //               array(
  //                 'mentorId' => $mentorId
  //               )
  //             );

  //           } else {
  //             // create cert
  //             $wpdb->insert(
  //               'wp_certification', 
  //               array(
  //                 "certificationName" => strtolower($certifications[$i]['certificationName']),
  //                 "mentorId" => $mentorId
  //               )
  //             );

  //           }
  //         }
  //       }

  //       if(!empty($wpdb->last_error)){
  //         return new WP_Error(400, $wpdb->last_error);
  //       } else {
  //         return rest_ensure_response(array(
  //           "success" => true,
  //           "message" => "Mentor's skills and certifications have been updated."
  //         ));
  //       }

  //     // } else {
  //       // user is not logged in as the current user
  //     // }

  // }

  public function delete_qualifications(WP_REST_Request $request)
  {
    global $wpdb;

    /*
      Required info:
        - skills []
        - certifications []
    */

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    $post_array = $request->get_json_params();

    if ($post_array['skills']) {
      $skills = $post_array['skills'];
      $skills_length = count($skills);
      for ($i = 0; $i < $skills_length; $i++) {
        // Delete a skill
        $delete_result = $wpdb->query(
          $wpdb->prepare(
            "DELETE FROM wp_skill WHERE skillId = %d AND mentorId = %d",
            array(
              $skills[$i],
              $mentorId
            )
          )
        );
      }
    }

    if ($post_array['certifications']) {
      $certifications = $post_array['certifications'];
      $certifications_length = count($certifications);
      for ($i = 0; $i < $certifications_length; $i++) {
        // Delete a certification
        $delete_result = $wpdb->query(
          $wpdb->prepare(
            "DELETE FROM wp_certification WHERE certificationId = %d AND mentorId = %d",
            array(
              $certifications[$i],
              $mentorId
            )
          )
        );
      }
    }

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(array(
        "success" => true,
        "message" => "Mentor's qualifications(skills/certs) have been deleted."
      ));
    }
  }


  public function delete_profile(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {


    /**
     *   Required info: 
     * 
     *    - mentorId
     * 
     */

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;

    // if ($mentorId){
    // user is logged in as the current user

    // $delete_result = $wpdb->query(
    //   $wpdb->prepare(
    //     "DELETE FROM wp_certification WHERE mentorId = %d",
    //     array(
    //       $mentorId
    //     )
    //   )
    // );

    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_skill WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );


    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_AvailableTime WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );


    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_reservationTime 
            WHERE timeId IN (
              SELECT r.timeId 
              FROM wp_reservation r 
              WHERE r.reservationId IN (
                SELECT c.reservationId 
                FROM wp_ReservationMentorMap c 
                WHERE c.mentorId = %d
          ))",
        array(
          $mentorId
        )
      )
    );


    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_reservationTime 
            WHERE timeId IN (
              SELECT r.timeId 
              FROM wp_reservation r 
              WHERE r.reservationId IN (
                SELECT c.reservationId 
                FROM wp_ReservationMentorMap c 
                WHERE c.mentorId = %d 
          ))",
        array(
          $mentorId
        )
      )
    );

    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_reservation
            WHERE reservationId IN (
              SELECT r.reservationId 
              FROM wp_ReservationMentorMap r
              WHERE r.mentorId = %d
          )",
        array(
          $mentorId
        )
      )
    );


    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_ReservationMentorMap
            WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );


    $wpdb->query(
      $wpdb->prepare(
        "DELETE FROM wp_Mentor WHERE mentorId = %d",
        array(
          $mentorId
        )
      )
    );

    if (!empty($wpdb->last_error)) {
      return new WP_Error(400, $wpdb->last_error);
    } else {
      return rest_ensure_response(
        array(
          "success" => true,
          "message" => "Mentor has been deleted."
        )
      );
    }

    // } else {
    // user is not logged in as the current user

    // }   

    // }
  }
}
