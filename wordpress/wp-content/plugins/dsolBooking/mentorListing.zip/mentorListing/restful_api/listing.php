<?php
require_once('Authentication.php');

class Listing_Posts_Controller
{

  public function __construct()
  {
    $this->namespace = 'mentor-listing/v1';
    $this->resource_name = 'listings';
  }

  public function register_routes()
  { 
    register_rest_route($this->namespace, '/testlisting', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'test')
      )
    ));

    register_rest_route($this->namespace, '/listings', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_listings_all')
      )
    ));

    register_rest_route($this->namespace, '/listings/limit/(?P<limit>\d+)', array(
      // Here we register the readable endpoint for collections.
      array(
          'methods'   => 'GET',
          'callback'  => array($this, 'get_listings_limit')
      )
    ));

    register_rest_route($this->namespace, '/listing/create', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'create_listing')
      )
    ));

    register_rest_route($this->namespace, '/listing/(?P<id>\d+)', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'get_listing')
      )
    ));

    register_rest_route($this->namespace, '/listing/edit', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'edit_listing')
      )
    ));

    register_rest_route($this->namespace, '/listing/delete', array(
      // Here we register the readable endpoint for collections.
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'delete_listing')
      )
    ));
  }

  public function test(WP_REST_Request $request){
    $success = 'You have successfully connected to the listing TEST route';
    return rest_ensure_response($success);

  } 


  public function get_listings_all(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {
      $sql = "SELECT 
                    m.user_id AS mentorId,
                    u.user_email AS mentorEmail,
                    u.user_nicename AS mentorName,
                    -- GROUP_CONCAT(
                    --   DISTINCT CONCAT_WS(', ', awt.timeId, awt.startDate, awt.endDate, awt.openTime, awt.closeTime, awt.recurring)
                    --   SEPARATOR ' ; ' 
                    -- ) AS availableTimes,
                    GROUP_CONCAT(
                      DISTINCT CONCAT_WS(', ', r.reservationId, r.email, r.name, r.phone, rt.timeId, rt.startTime, rt.endTime )
                      SEPARATOR ' ; ' 
                    ) AS reservations
                  FROM wp_usermeta m
                  INNER JOIN wp_users u 
                    ON m.user_id = u.ID
                  LEFT JOIN wp_AvailableTime awt
                    ON m.user_id = awt.mentorId
                  LEFT JOIN wp_ReservationMentorMap c
                    ON m.user_id = c.mentorId
                  LEFT JOIN wp_reservation r
                    ON c.reservationId = r.reservationId
                  LEFT JOIN wp_reservationTime rt
                    ON r.timeId = rt.timeId
                  WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                  GROUP BY m.user_id, u.user_email, u.user_nicename
                  ORDER BY m.user_id";

      $results = $wpdb->get_results($sql, ARRAY_A);
      
      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } 

      if ($wpdb->num_rows > 0) {
        return rest_ensure_response($results);
      } else {
        return rest_ensure_response([]);
      }
    // }

  }

  public function get_listings_limit(WP_REST_Request $request)
  {
    global $wpdb;

     /**
     *  startIndex = (25 * ($pageIndex-1)) + 1
     *  endIndex = 25 * $pageIndex
     * 
     */

    $pageIndex = is_numeric($request['limit']) ? intval($request['limit']) : null;

    $startIndex = (25 * ($pageIndex-1));
    $endIndex = 25 * $pageIndex;

    $sql = "SELECT  m.user_id AS mentorId,
                    u.user_email AS mentorEmail,
                    u.user_nicename AS mentorName,
                    GROUP_CONCAT(
                      DISTINCT CONCAT_WS(', ', r.reservationId, r.email, r.name, r.phone, rt.timeId, rt.startTime, rt.endTime )
                      SEPARATOR ' ; ' 
                    ) AS reservations
                  FROM wp_usermeta m
                  INNER JOIN wp_users u 
                    on m.user_id = u.ID
                  LEFT JOIN wp_AvailableTime awt
                    ON m.user_id = awt.mentorId
                  LEFT JOIN wp_ReservationMentorMap c
                    ON m.user_id = c.mentorId
                  LEFT JOIN wp_reservation r
                    ON c.reservationId = r.reservationId
                  LEFT JOIN wp_reservationTime rt
                    ON r.timeId = rt.timeId
                  WHERE m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                  GROUP BY m.user_id, u.user_email, u.user_nicename
                  LIMIT $startIndex, $endIndex";

      $results = $wpdb->get_results($sql, ARRAY_A);

      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } 

      if ($wpdb->num_rows > 0) {
        return rest_ensure_response($results);
      } else {
        return rest_ensure_response([]);
      }
  }


  public function create_listing(WP_REST_Request $request)
  {
    global $wpdb;

    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info:
     *    - mentorId 
     *    - startTime
     *    - endTime
     *    - email
     *    - name
     *    - phone
     *    - isApproved
     */

      // $current_user = wp_get_current_user();
      // $mentorId = $current_user->ID;

      $post_array = $request->get_json_params();

    
      // Time: YYYY-MM--DD HH:MM:SS
      $wpdb->insert(
        'wp_reservationTime', 
        array(
          "startTime" => $post_array['startTime'],
          "endTime" => $post_array['endTime']
        )
      );

      $timeId = $wpdb->insert_id;

      $wpdb->insert(
        'wp_reservation',
        array (
          "email" => strtolower($post_array['email']),
          "name" => strtolower($post_array['name']),
          "phone" => $post_array['phone'],
          "timeId" => $timeId,
          "isApproved" => $post_array['isApproved']
        )
      );


      $resId = $wpdb->insert_id;
      
      $date = explode(" ", $startTime)[0];

      $wpdb->insert(
        'wp_ReservationMentorMap',
        array (
          "mentorId" => $post_array['$mentorId'],
          "reservationId" => $resId,
          "date" => $date
        )
      );

      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } else {
        return rest_ensure_response(array(
          "success" => true,
          "message" => "Listing has been created."
        ));
      }
    // }
  }

  public function get_listing(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     *   - mentorId
     * 
     */

     $mentorId = is_numeric($request['id']) ? intval($request['id']) : null;
    
     if ($mentorId){
        $sql = "SELECT 
                  m.user_id AS mentorId,
                  GROUP_CONCAT(
                      DISTINCT CONCAT_WS(', ', r.reservationId, r.email, r.name, r.phone, rt.timeId, rt.startTime, rt.endTime )
                      SEPARATOR ' ; ' 
                    ) AS reservations
                FROM wp_usermeta m
                INNER JOIN wp_users u 
                  on m.user_id = u.ID
                LEFT JOIN wp_ReservationMentorMap c
                  ON m.user_id = c.mentorId
                LEFT JOIN wp_reservation r
                  ON c.reservationId = r.reservationId
                LEFT JOIN wp_reservationTime rt
                  ON r.timeId = rt.timeId
                WHERE m.user_id = $mentorId 
                  AND m.meta_value LIKE 'a:1:{s:6:\"mentor\";b:1;}'
                ORDER BY m.user_id";

        $results = $wpdb->get_results($sql, ARRAY_A);
        
        if(!empty($wpdb->last_error)){
          return new WP_Error(400, $wpdb->last_error);
        } 

        if ($wpdb->num_rows > 0) {
          return rest_ensure_response($results);
        } else {
          return rest_ensure_response([]);
        }

     } else {
      return rest_ensure_response('MentorId is null.');
     }
     
     // }

  }


  public function edit_listing(WP_REST_Request $request)
  { 
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     * 
     *    - timeId
     *    - startTime, endTime
     *    - reservationId
     *    - email
     *    - phone
     *    - name
     *    - isApproved
     * 
     */

    

        // user is logged in 
        $current_user = wp_get_current_user();
        $mentorId = $current_user->ID;

        $post_array = $request->get_json_params();  
        $times = $post_array['times'];
        $times_size = count($post_array['times']);

        for ($i=0; $i<$times_size; $i++){

          $timeId = $times[$i]['timeId'];

          if ($timeId){
      
            $wpdb->update(
              'wp_reservationTime',
              array(
                'startTime' => $times[$i]['startTime'],
                'endTime' => $times[$i]['endTime']
              ),
              array('timeId' => $timeId)
            );
          
            $wpdb->update(
              'wp_reservation',
              array(
                'email' => $times[$i]['email'],
                'name' => $times[$i]['name'],
                "phone" => $times[$i]['phone'],
                "isApproved" =>  $times[$i]['isApproved']
              ),
              array('reservationId' => $times[$i]['reservationId'])
            );

            // convert timestamp to date format & GET only the YYYY-MM--DD
            $date = explode(" ", $times[$i]['startTime'])[0];

            // date: YYYY-MM--DD
            $wpdb->query(
              $wpdb->prepare(
                "UPDATE wp_ReservationMentorMap c 
                  SET c.date = %s
                  WHERE c.reservationId IN ( 
                    SELECT r.reservationId 
                    FROM reservation r 
                    WHERE r.timeId = %d) 
                  AND c.mentorId = %d",
                array(
                  $date, 
                  $timeId,
                  $mentorId
                )
              )
            );

            
          } 
        }

        if(!empty($wpdb->last_error)){
          return new WP_Error(400, $wpdb->last_error);
        } else {
          return rest_ensure_response(array(
            "success" => true,
            "message" => "Listing has been updated."
          ));
        }

      // } else {
        // user is not logged in as the current user
      // }

  }

  public function delete_listing(WP_REST_Request $request)
  {
    global $wpdb;
    // if (Authentication::authorization_status_code() == 200) {

    /**
     *   Required info: 
     *    - timeId
     */

    $current_user = wp_get_current_user();
    $mentorId = $current_user->ID;
    
    $post_array = $request->get_json_params();
    $timeId = $post_array['time'];

  
    // if ($mentorId){

      $wpdb->query(
        $wpdb->prepare(
          "DELETE FROM wp_ReservationMentorMap 
            WHERE reservationId IN 
              (SELECT r.reservationId FROM wp_reservation r WHERE r.timeId = %d) 
            AND mentorId = %d",
          array(
            $timeId,
            $mentorId
          )
        )
      );

      $wpdb->query(
        $wpdb->prepare(
          "DELETE FROM wp_reservationTime WHERE timeId = %d",
          array(
            $timeId
          )
        )
      );

      $wpdb->query(
        $wpdb->prepare(
          "DELETE FROM wp_reservation WHERE timeId = %d",
          array(
            $timeId
          )
        )
      );

      if(!empty($wpdb->last_error)){
        return new WP_Error(400, $wpdb->last_error);
      } else {
        return rest_ensure_response(array(
          "success" => true,
          "message" => "Listing has been deleted."
        ));
      }

    // } else {
      // not current user
      
    // }
    // }
   }
}
?>