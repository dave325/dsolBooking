<?php
/*
Plugin Name: D Solutions Mentor Listing
Plugin URI: https://github.com/dave325/mentorListing
Description: Figure it out
Version: 1.0.0
Author: David Solutions 
Author URI: http://dataramsolutions.com
License: GPLv2 or later
Text Domain: dsol-booking
*/
global $dsol_mentor_version;
$dsol_mentor_version = "1";

define('DSOL_MENTOR_PATH', plugin_dir_path(__FILE__));

require_once(DSOL_MENTOR_PATH . 'restful_api/init_routes.php');
/**
 * Change init functions and class
 */
register_activation_hook(__FILE__, array('DsolMentorListingHooks', 'on_activate'));
register_deactivation_hook(__FILE__, array('DsolMentorListingHooks', 'on_deactivate'));
register_uninstall_hook(__FILE__, array('DsolMentorListingHooks', 'on_uninstall'));

add_action('init', 'dSol_mentor_enqueuer');

#add_filter( 'the_content',  array( 'dsol_public', 'mainForm' ) );

add_action('admin_notices', array('DsolMentorListingHooks', 'plugin_activation_message'));

//add_action('admin_menu', array('dsol_settings', 'add_settingsPage'));

#add_filter(		'gform_pre_render',			array( 'dsol_creditCardPayments', 'returnIncomingValidation' ) );
#add_action(		'gform_after_submission',	array( 'dsol_creditCardPayments', 'finishedSubmission' ));

add_action('show_user_profile', 'crf_show_extra_profile_fields');
add_action('edit_user_profile', 'crf_show_extra_profile_fields');

function crf_show_extra_profile_fields($user)
{
    $skills = get_user_meta($user->ID, 'skills', true);
    $certifications = get_user_meta($user->ID, 'certifications', true);
    ?>
    <h3><?php esc_html_e('Personal Information', 'crf'); ?></h3>

    <table class="form-table">
        <tr>
            <th><label for="skills"><?php esc_html_e('Skills', 'crf'); ?></label></th>
            <td>
                <input type="text" id="skills" name="skills" value="<?php echo esc_attr($skills); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="certifications"><?php esc_html_e('Certifications', 'crf'); ?></label></th>
            <td>
                <input type="text" id="certifications" name="certifications" value="<?php echo esc_attr($certifications); ?>" class="regular-text" />
            </td>
        </tr>
    </table>
<?php
}

add_action('user_profile_update_errors', 'crf_user_profile_update_errors', 10, 3);
function crf_user_profile_update_errors($errors, $update, $user)
{

    if (!$update) {
        return;
    }
    if (empty($_POST['skills'])) {
        $errors->add('skills_error', __('<strong>ERROR</strong>: Please enter your skills.', 'crf'));
    }
    if (empty($_POST['certifications'])) {
        $errors->add('certifications_error', __('<strong>ERROR</strong>: Please enter your certifications.', 'crf'));
    }
}


add_action('personal_options_update', 'crf_update_profile_fields');
add_action('edit_user_profile_update', 'crf_update_profile_fields');

function crf_update_profile_fields($user_id)
{
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    if (!empty(get_user_meta( $user_id,'skills'))) {
        if (!empty($_POST['skills'])) {
            update_user_meta($user_id, 'skills', $_POST['skills']);
        }
        if (!empty($_POST['certifications'])) {
            update_user_meta($user_id, 'certifications', $_POST['certifications']);
        }
    } else {
        add_user_meta($user_id, 'skills', $_POST['skills']);
        
    }
    if (!empty(get_user_meta( $user_id,'certifications'))) {
        if (!empty($_POST['certifications'])) {
            update_user_meta($user_id, 'certifications', $_POST['certifications']);
        }
    } else {
        add_user_meta($user_id, 'certifications', $_POST['certifications']);
        
    }
}
function add_cors_http_header()
{
    header("Access-Control-Allow-Origin", "*");
    header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH,OPTIONS');
    header("Access-Control-Allow-Headers", "Access-Control-Allow-Origin,Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, X-WP-NONCE, Access-Control-Request-Headers");
    header("Access-Control-Allow-Credentials", "true");
}
add_action('rest_pre_serve_request', 'add_cors_http_header');

function dSol_mentor_enqueuer()
{

    $token = "DEFJJIADOEXV7KG5I2RKI56NV6RIDZXF";
	$url = 'https://calendly.com/api/v1/hooks?url=' . get_site_url() . '/wp-json/dsol-booking/v1/hooks&events[]=invitee.created';
	$data = array('url' => get_site_url() . '/wp-json/dsol-booking/v1/hooks', 'events[]' => 'invitee.created');

	// use key 'http' even if you send the request to https://...
	$options = array(
		'http' => array(
			'header'  => "X-token: " . $token,
			'method'  => 'GET',
			'content' => http_build_query($data)
		)
	);

	//var_dump($result); 
	// Get cURL resource
	$curl = curl_init();
	// Set some options - we are passing in a useragent too here
	curl_setopt_array($curl, [
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => $url,
		CURLOPT_HTTPHEADER => ["X-token: " . $token]
	]);
	// Send the request & save response to $resp
	$resp = curl_exec($curl);
	var_dump($resp);
	// Close request to clear up some resources
	curl_close($curl);
    // TODO - Set up application shortcodepages here 
    global $dsol_mentor_version;
    wp_enqueue_script('jquery');

    add_shortcode('dsol_app', array('DSOLPage', 'display'));
    add_shortcode('dsol_app_profile', array('DSOLPage', 'display1'));

    //wp_enqueue_style('vuematerialcss',"https://unpkg.com/vue-material/dist/vue-material.min.css",array(), '');
    //wp_enqueue_style('vuematerialdefaultcss',"https://unpkg.com/vue-material/dist/theme/default.css",array(), '');   
    wp_enqueue_style('bootstrapcss', "https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css", array(), '');
    wp_enqueue_style('font', '//fonts.googleapis.com/css?family=Roboto:400,500,700,400italic|Material+Icons', array(), '');


    foreach (scandir(DSOL_MENTOR_PATH . 'dist/js') as $file) {
        $temp = pathinfo(DSOL_MENTOR_PATH . 'dist/js/' . $file);
        if ($temp['extension'] == "map") {
            continue;
        }
        if (strlen($temp['filename']) > 0 && $temp['extension'] == "js") {
            wp_enqueue_script($temp['filename'], plugins_url("mentorListing/dist/js/" . $temp['basename']), array(), '', true);
            wp_localize_script(
                $temp['filename'],
                'dsolMentorPlugin',
                array(
                    'partials' => plugins_url('mentorListing/'),
                    "path" =>  get_site_url(),
                    'nonce' => wp_create_nonce('wp_rest'),
                    'username' => wp_get_current_user()
                )
            );
        }
    }
    foreach (scandir(DSOL_MENTOR_PATH . 'dist/css') as $file) {
        $temp = pathinfo(DSOL_MENTOR_PATH . 'dist/css/' . $file);
        if (strlen($temp['filename']) > 0 && $temp['extension'] == "css") {
            wp_enqueue_style($temp['filename'], plugins_url("mentorListing/dist/css/" . $temp['basename']), array(), '');
        }
    }
    if (get_role('mentor') == null) {
        add_role(
            'mentor',
            __('Mentor'),
            array(
                'read' => true, // Allows a user to read
                'create_posts' => true, // Allows user to create new posts
                'edit_posts' => true, // Allows user to edit their own posts
            )
        );
    }
}
add_action('admin_menu', 'test_plugin_setup_menu');
function test_plugin_setup_menu(){
    add_menu_page( 'Test Plugin Page', 'Test Plugin', 'manage_options', 'test-plugin', array('DSOLPage', 'adminPage') );
}


class DSOLPage
{
    public static function adminPage(){
        require_once(DSOL_MENTOR_PATH . 'info.html');
    }
    public static function display()
    {
        ob_start();
        require_once(DSOL_MENTOR_PATH . 'info.html');
        return ob_get_clean();
    }
    public static function display1()
    {
        ob_start();
        require_once(DSOL_MENTOR_PATH . 'info1.html');
        return ob_get_clean();
    }
}
class DsolMentorListingHooks
# simple class for activating, deactivating and uninstalling plugin
{
    public static function on_activate($dbOnly = false)
    # this is only run when hooked by activating plugin
    {

        global $wpdb;
        global $dsol_mentor_version;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        # create table for skill
        $sql = "CREATE TABLE {$wpdb->prefix}dsol_skill
        (
            `skillName` varchar(128) NOT NULL,
            `mentorId` int PRIMARY KEY NOT NULL,
        PRIMARY KEY (`mentorId`)
        );";
        dbDelta($sql);

        # create table for certification 
        $sql = "CREATE TABLE {$wpdb->prefix}dsol_certification
        (
            `certificationName` varchar(128) NOT NULL,
            `mentorId` int PRIMARY KEY NOT NULL,
        PRIMARY KEY (`mentorId`)
        );";
        dbDelta($sql);

        if ($dbOnly) {
            update_option("dsol_mentor_version", $dsol_mentor_version);
            return true;
        }
    }

    public static function plugin_activation_message()
    {
        global $dsol_mentor_version;
        if ($dsol_mentor_version !== get_option("dsol_mentor_version")) {
            DsolMentorListingHooks::on_activate(true);
        }

        if (get_option("dsol_installing") == 'yes') {
            update_option('dsol_installing', 'no');
            $html = '<div class="updated">' . __('(Please install the events calendar plugin. You will not be able to view the calendar until it is installed and configured.)', 'book-a-room') .  '</p>' .
                '<p>' . __('To set up your meeting rooms, first click on Meeting Room Settings on the left hand menu. There are descriptions of each option at the bottom of the page.', 'book-a-room') . '</p>' .
                '<p>' . __('Next, set up your amenities. These should include any extras that can be reserved with the room like coffee urns, dry erase boards and projectors.', 'book-a-room') . '</p>' .
                '<p>' . __('Once you\'ve got your amenities set, add your Branches. This is also where you configure the hours, address and image for each branch.', 'book-a-room') . '</p>' .
                '<p>' . __('Next, add in your Rooms. A room is a <em><strong>physical</strong></em> space that can be reserved. If you have 2 meetings rooms, even if they can be reserved together, you would only add the two physical locations as a room.', 'book-a-room') . '</p>' .
                '<p>' . __('Finally, add in your Room Containers. Room containers are <em><strong>virtual</strong></em> spaces that are actually being reserved. If you have two rooms that can be reserved separately or together as one larger space, you would add 3 containers; two would each contain one room and the third would contain both rooms.', 'book-a-room') . '</p>' .
                '<p>' . __('To configure alerts and content, make sure you edit the Email Admin and Content Admin!', 'book-a-room') . '</p>' .
                '</div><!-- /.updated -->';
            echo $html;
        }
    }

    public static function on_deactivate()
    # this is only run when hooked by de-activating plugin
    {
        # TODO fix deactivation and uninstall
        #update_option( "dsol_installing", 'yes' );



    }

    public static function on_uninstall()
    # this is only run when hooked by uninstalling plugin
    {
        // important: check if the file is the one that was registered with the uninstall hook (function)

        #if ( __FILE__ != WP_UNINSTALL_PLUGIN )
        #    return;

        global $wpdb;
        global $dsol_mentor_version;


        delete_option("dsol_db_version");
    }
}


class dsol_mentor_settings
# main settings functions
{
    public static function add_settingsPage()
    {




        #initialize		
        add_action('admin_init', array('dsol_settings', 'dsol_init'));
    }



    public static function dsol_init()
    { }
}
