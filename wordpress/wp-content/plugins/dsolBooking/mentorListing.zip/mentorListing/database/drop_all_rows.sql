/*
  Running these commands will drop all the ROWS for the db
*/

delete from wp_Mentor;
delete from wp_skill;
delete from wp_certification;
delete from wp_AvailableTime;
delete from wp_reservationTime;
delete from wp_reservation;
delete from wp_ReservationMentorMap;
