/*
	DUMMY DATA
	
		This file contains all the INSERTION OF DUMMY DATA QUERIES

		- Kelvin

*/

/******************************************************************************************/

-- ADD A NEW MENTOR

-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (1, "bobby jackson", "abc@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (1, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 1, 1);

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (7, "2019-02-01", "2019-03-25", "09:00:00", "17:00:00", 1, 1);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (1, "fishing", 1);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (2, "baking", 1);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (3, "woodcutting", 1);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (1, "aws academy", 1);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (2, "mna academy", 1);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (3, "kol academy", 1);

/********************************/

-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (2, "annie pope", "adfsd@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (2, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 1, 2);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (4, "woodcutting", 2);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (5, "firemaking", 2);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (6, "baking", 2);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (4, "aws academy", 2);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (5, "mna academy", 2);

/********************************/


-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (3, "susan tomas", "tertwqe@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (3, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 1, 3);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (7, "blacksmith", 3);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (8, "sandwich maker", 3);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (6, "pq academy", 3);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (7, "kl academy", 3);

/********************************/

-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (4, "eve jackson", "zxcv@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (4, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 1, 4);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (9, "sword fishing", 4);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (10, "javascript", 4);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (8, "aws academy", 4);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (9, "akw academy", 4);

/********************************/

-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (5, "mary land", "qwerty@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (5, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 0, 5);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (11, "sleeping", 5);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (12, "eating", 5);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (10, "awe Academy", 5);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (11, "tyr Academy", 5);

/********************************/

-- INSERT INTO wp_Mentor (mentorId, mentor_name, email)
-- VALUES (6, "adam smith", "cmakdewa@gmail.com");

INSERT INTO wp_AvailableTime (timeId, startDate, endDate, openTime, closeTime, recurring, mentorId)
VALUES (6, "2019-01-01", "2019-01-25", "09:00:00", "17:00:00", 0, 6);

INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (13, "ebay seller", 6);
INSERT INTO wp_skill (skillId, skillName, mentorId)
VALUES (14, "walking", 6);

INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (12, "mna academy", 6);
INSERT INTO wp_certification (certificationId, certificationName, mentorId)
VALUES (13, "kol academy", 6);

/******************************************************************************************/

-- MAKE A NEW RESERVATION

INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (1, "2019-01-01 09:00:00", "2019-01-01 09:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (1, "dylan123@gmail.com", "dylan smith", "1-800-355-0122", 1, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (1, 1, 1, "2019-01-01");


INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (2, "2019-01-01 10:00:00", "2019-01-01 10:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (2, "diana123@gmail.com", "diana pie", "1-800-355-0123", 2, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (2, 2, 2, "2019-01-01");

INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (3, "2019-01-02 09:00:00", "2019-01-02 09:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (3, "don123@gmail.com", "don draper", "1-800-355-1111", 3, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (3, 3, 3, "2019-01-02");


INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (4, "2019-01-02 13:00:00", "2019-01-02 13:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (4, "walter123@gmail.com", "walter white", "1-800-355-1222", 4, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (4, 4, 4, "2019-01-02");

INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (5, "2019-01-03 09:00:00", "2019-01-03 09:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (5, "adam123@gmail.com", "adam smith", "1-800-355-1222", 5, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (5, 5, 5, "2019-01-03");

INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (6, "2019-01-03 13:00:00", "2019-01-03 13:30:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (6, "james123@gmail.com", "james sour", "1-800-355-1202", 6, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (6, 6, 6, "2019-01-03");


INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (66, "2019-01-03 13:30:00", "2019-01-03 14:00:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (66, "open@gmail.com", "open door", "1-800-355-1202", 66, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (66, 6, 66, "2019-01-03");

/******************************************************************************************/

INSERT INTO wp_reservationTime (timeId, startTime, endTime)
VALUES (99, "2019-01-05 10:30:00", "2019-01-05 11:00:00");

INSERT INTO wp_reservation (reservationId, email, name, phone, timeId, isApproved)
VALUES (99, "kelvin@gmail.com", "kelvin l", "1-800-355-0122", 99, 1);

INSERT INTO wp_ReservationMentorMap (mapId, mentorId, reservationId, date)
VALUES (99, 1, 99, "2019-01-01");